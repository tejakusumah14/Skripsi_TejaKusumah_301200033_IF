<footer class="sticky-footer bg-white">
	<div class="container my-auto">
		<div class="copyright text-center my-auto">
			<span>copyright by © 2024 by <a href="https://duniamu38.com" target="_blank">Teja Kusumah</a></span>
		</div>
	</div>
</footer>